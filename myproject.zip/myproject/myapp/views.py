from django.shortcuts import render, HttpResponse

def index(request):
    return render(request, 'index.html')
    # return HttpResponse("this is home page")

def about(request):
    # return HttpResponse("this is about page")
    return render(request, 'about.html')


def services(request):
    # return HttpResponse("this is services page")
    return render(request, 'services.html')


def contact(request):
    # return HttpResponse("this is contact page")
    return render(request, 'contact.html')

# Create your views here.
